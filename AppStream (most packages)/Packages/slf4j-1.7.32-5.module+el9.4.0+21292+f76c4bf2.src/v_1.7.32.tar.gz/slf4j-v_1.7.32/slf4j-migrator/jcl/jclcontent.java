/**
*This is not a class, just a sample of some jcl source code to convert
*/
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;


Log l = LogFactory.getLog(MyClass.class);
Log mylog=LogFactory.getLog(MyClass.class);
Log mylog1 = LogFactory.getLog(MyClass.class);
Log mylog2  =    LogFactory.getLog(MyClass.class);

Log log3=LogFactory.getFactory().getInstance(MyClass.class);
Log mylog4 = LogFactory.getFactory().getInstance(MyClass.class);
Log mylog5 = LogFactory.getLog(MyClass.class);

Log myLog6;

log7=LogFactory.getFactory().getInstance(MyClass.class);
log8 =LogFactory.getFactory().getInstance(MyClass.class);
myLog9  =  LogFactory.getLog(MyClass.class);

