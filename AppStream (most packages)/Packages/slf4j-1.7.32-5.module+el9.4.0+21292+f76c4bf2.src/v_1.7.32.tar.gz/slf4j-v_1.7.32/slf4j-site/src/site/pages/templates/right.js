document.write('      <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>');
//      <!-- SLF4J -->
document.write('      <ins class="adsbygoogle"');
document.write('           style="display:block"');
document.write('           data-ad-client="ca-pub-7471410671306824"');
document.write('           data-ad-slot="7413932813"');
document.write('           data-ad-format="auto"></ins>');
document.write('      <script>');
document.write('        (adsbygoogle = window.adsbygoogle || []).push({});');
document.write('      </script>;');
