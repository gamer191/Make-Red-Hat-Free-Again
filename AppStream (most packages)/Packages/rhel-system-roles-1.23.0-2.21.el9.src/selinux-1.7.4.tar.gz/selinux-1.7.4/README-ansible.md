# Introduction to Ansible for Linux System Roles

If you are not familiar with Ansible, please see
[Introduction to Ansible for Linux System Roles](https://linux-system-roles.github.io/documentation/intro-to-ansible-for-system-roles.html),
where many useful links are presented.
