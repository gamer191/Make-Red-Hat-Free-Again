Changelog
=========

[1.1.1] - 2024-01-16
--------------------

### Other Changes

- ci: Use supported ansible-lint action; run ansible-lint against the collection (#12)
- ci: Use supported ansible-lint action; run ansible-lint against the collection (#13)

[1.1.0] - 2023-12-08
--------------------

### New Features

- feat: several role improvements (#8)

### Other Changes

- refactor: get_ostree_data.sh use env shebang - remove from .sanity* (#10)

[1.0.0] - 2023-11-27
--------------------

### New Features

- feat: New Role to manage fapolicyd
