*NOTE*: The `*.txt` files are used by `get_ostree_data.sh` to create the lists
of packages, and to find other system roles used by this role.  DO NOT use them
directly.

The script `meta/make_ostree_packages_files` is used to generate these files.
