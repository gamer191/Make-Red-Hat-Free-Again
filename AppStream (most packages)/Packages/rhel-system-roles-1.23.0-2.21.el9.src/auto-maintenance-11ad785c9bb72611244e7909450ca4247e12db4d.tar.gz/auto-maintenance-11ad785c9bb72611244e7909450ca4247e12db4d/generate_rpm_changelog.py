#!/usr/bin/python3

from get_collection_version import get_collection_version

print("- Update to upstream version {}".format(get_collection_version()))
