# Rsyslog Provider

This sub-tree contains the rsyslog implementation.

Rsyslog specific configuration will be described here if any.
