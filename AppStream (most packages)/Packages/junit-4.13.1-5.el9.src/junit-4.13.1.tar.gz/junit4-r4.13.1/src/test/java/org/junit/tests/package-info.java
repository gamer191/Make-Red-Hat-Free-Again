/**
 * Tests the JUnit functionality.
 *
 * Corresponds to {@link junit.tests.AllTests} in Junit 3.x.
 *
 * @since 4.0
 */
package org.junit.tests;