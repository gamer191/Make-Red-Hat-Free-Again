## Security and Disclosure Information Policy for the oci-seccomp-bpf-hook Project

The oci-seccomp-bpf-hook Project follows the [Security and Disclosure Information Policy](https://github.com/containers/common/blob/main/SECURITY.md) for the Containers Projects.
