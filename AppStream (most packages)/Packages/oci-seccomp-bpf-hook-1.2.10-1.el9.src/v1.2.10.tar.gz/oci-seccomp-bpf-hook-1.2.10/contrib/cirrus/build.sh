#!/bin/bash

set -e

source $(dirname $0)/lib.sh

make

ls -la bin
