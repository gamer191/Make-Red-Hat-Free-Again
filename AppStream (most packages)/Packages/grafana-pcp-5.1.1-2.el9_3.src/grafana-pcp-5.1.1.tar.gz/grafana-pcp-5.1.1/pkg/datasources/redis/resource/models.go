package resource

// MetricFindValue is the response for metricFindQuery
type MetricFindValue struct {
	Text string `json:"text"`
}
