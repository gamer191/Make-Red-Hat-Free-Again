# Moved

This document has moved to https://grafana-pcp.readthedocs.io/en/latest/datasources/redis.html
