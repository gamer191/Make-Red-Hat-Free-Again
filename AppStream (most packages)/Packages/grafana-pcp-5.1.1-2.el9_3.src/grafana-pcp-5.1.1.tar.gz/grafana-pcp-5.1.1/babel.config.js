module.exports = {
    "plugins": [
        [ "react-remove-properties", { "properties": ["data-test"] } ],
    ],
};
