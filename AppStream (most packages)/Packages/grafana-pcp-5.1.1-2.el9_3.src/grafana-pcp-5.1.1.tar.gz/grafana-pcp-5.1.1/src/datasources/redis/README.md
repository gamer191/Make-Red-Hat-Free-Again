# PCP Redis

#### [Data source documentation](https://grafana-pcp.readthedocs.io/en/latest/datasources/redis.html)
