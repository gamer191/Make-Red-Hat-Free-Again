export const SET_QUERY = 'SET_QUERY';
export const CLEAR_QUERY = 'CLEAR_QUERY';
