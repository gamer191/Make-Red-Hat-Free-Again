export enum ViewState {
    Detail,
    Search,
    Index,
}

export const initialView = () => ViewState.Index;
