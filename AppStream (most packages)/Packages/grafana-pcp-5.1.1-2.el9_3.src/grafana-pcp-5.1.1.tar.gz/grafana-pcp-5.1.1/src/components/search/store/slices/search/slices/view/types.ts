export const SET_VIEW = 'SET_VIEW';
