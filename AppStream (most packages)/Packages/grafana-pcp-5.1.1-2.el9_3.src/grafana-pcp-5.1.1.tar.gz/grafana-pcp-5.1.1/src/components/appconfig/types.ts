export interface AppSettings {}
