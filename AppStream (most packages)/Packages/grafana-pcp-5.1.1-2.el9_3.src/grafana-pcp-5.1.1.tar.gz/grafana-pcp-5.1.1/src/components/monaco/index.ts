import type * as MonacoType from 'monaco-editor/esm/vs/editor/editor.api';

export type { MonacoType };
export declare type Monaco = typeof MonacoType;
