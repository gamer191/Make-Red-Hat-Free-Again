Exceptions
==========

.. automodule:: websockets.exceptions
    :members:

