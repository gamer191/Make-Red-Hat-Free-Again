# Security

## Policy

Only the latest version receives security updates.

## Contact information

Please report security vulnerabilities to the
[Tidelift security team](https://tidelift.com/security).

Tidelift will coordinate the fix and disclosure.
