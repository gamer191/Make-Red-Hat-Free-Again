#
# Copyright (C) 2019 FreeIPA Contributors see COPYING for license
#

__import__('pkg_resources').declare_namespace(__name__)
