#
# Copyright (C) 2021 FreeIPA Contributors see COPYING for license
#

class TimeoutError(Exception):
    pass
