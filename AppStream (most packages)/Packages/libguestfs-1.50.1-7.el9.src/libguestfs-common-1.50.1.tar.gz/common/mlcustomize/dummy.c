/* Dummy source, to be used for OCaml-based tools with no C sources. */
enum { foo = 1 };
