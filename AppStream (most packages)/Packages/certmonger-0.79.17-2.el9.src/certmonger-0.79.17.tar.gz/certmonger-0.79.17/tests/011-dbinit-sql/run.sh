#!/bin/bash -e
exec env scheme=sql ../011-dbinit/run.sh
