#!/bin/bash -e
exec env scheme=dbm ../011-dbinit/run.sh
