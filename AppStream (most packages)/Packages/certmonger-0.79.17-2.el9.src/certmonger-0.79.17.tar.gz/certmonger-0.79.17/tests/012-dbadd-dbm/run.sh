#!/bin/bash -e
exec env scheme=dbm ../012-dbadd/run.sh
