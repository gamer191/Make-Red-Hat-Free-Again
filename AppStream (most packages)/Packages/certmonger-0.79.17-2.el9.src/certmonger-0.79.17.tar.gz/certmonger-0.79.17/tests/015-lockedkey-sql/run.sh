#!/bin/bash -e
exec env scheme=sql ../015-lockedkey/run.sh
