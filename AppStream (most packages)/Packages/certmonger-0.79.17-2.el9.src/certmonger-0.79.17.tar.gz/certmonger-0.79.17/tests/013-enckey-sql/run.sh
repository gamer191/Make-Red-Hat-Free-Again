#!/bin/bash -e
exec env scheme=sql ../013-enckey/run.sh
