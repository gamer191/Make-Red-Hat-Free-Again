#!/bin/bash -e
exec env scheme=sql ../012-dbadd/run.sh
