#!/bin/bash -e
exec env scheme=dbm: ../002-keygen/run.sh
