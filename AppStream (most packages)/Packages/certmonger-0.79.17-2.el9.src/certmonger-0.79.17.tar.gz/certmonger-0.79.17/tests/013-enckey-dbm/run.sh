#!/bin/bash -e
exec env scheme=dbm ../013-enckey/run.sh
