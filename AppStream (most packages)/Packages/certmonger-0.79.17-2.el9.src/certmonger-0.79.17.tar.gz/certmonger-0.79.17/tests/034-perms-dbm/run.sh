#!/bin/bash -e
exec env scheme=dbm: ../034-perms/run.sh
