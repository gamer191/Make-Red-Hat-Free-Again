#!/bin/bash
test -x $toolsdir/pk7parse && test -x $toolsdir/pk7env && test -x $toolsdir/addcinfo
