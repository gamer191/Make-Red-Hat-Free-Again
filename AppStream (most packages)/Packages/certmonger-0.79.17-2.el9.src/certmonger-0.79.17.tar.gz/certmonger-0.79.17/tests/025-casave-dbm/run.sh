#!/bin/bash -e

exec env scheme=dbm ../025-casave/run.sh
