#!/bin/bash -e
exec env scheme=sql: ../002-keygen/run.sh
