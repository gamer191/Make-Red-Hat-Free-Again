#!/bin/bash -e

exec env scheme=sql ../025-casave/run.sh
