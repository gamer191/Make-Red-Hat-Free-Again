#include "config.h"
#define FORCE_CA CM_SELF_SIGN_CA_NAME
#include "getcert.c"
