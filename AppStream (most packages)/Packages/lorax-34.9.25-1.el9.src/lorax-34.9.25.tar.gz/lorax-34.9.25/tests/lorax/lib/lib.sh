#!/usr/bin/env bash
# lorax specific functions

. "$(dirname $0)/../cli/lib/lib.sh"
