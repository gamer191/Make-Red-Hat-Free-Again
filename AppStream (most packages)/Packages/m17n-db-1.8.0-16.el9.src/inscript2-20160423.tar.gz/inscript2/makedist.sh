#!/bin/bash
echo "Creating tarball...."
cd ..
cp -pr inscript2 /tmp
cd /tmp/inscript2
date1=`date +%Y%m%d`
echo ${date1}
rm -rf .git .gitignore
cd ..
tar -cf inscript2-${date1}.tar inscript2
gzip inscript2-${date1}.tar
sha1sum inscript2-${date1}.tar.gz > inscript2-${date1}.tar.gz.sign
rm -rf /tmp/inscript2
echo "The tarball is created in /tmp directory"
