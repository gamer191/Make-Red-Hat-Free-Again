#include <stdio.h>

void initialize_my_empty_cffi(void);

int main(void)
{
    initialize_my_empty_cffi();
    printf("OK\n");
    return 0;
}

