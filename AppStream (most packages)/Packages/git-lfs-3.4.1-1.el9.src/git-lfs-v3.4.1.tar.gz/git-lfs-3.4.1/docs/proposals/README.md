# Git LFS Proposals

This directory contains high level proposals for future Git LFS features.
Inclusion here does not guarantee when or if a feature will make it in to Git
LFS. It doesn't even guarantee that the specifics won't change.

Everyone is welcome to submit their own proposal as a markdown file in a
pull request for discussion.
