'use strict'

module.exports = {
  splitData: require('./server-fuzz-split-data'),
  appendData: require('./server-fuzz-append-data')
}
