#!/usr/bin/python

import time

def web_socket_do_extra_handshake(request):
    time.sleep(2)

def web_socket_transfer_data(request):
    pass
