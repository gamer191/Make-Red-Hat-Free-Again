Tests for the [MIME Sniffing Standard](https://mimesniff.spec.whatwg.org/).

Some tests are generated from data files. To update the generated
tests, run `wpt update-built --include mimesniff`
