Tests for the [WebSockets Standard](https://websockets.spec.whatwg.org/).
