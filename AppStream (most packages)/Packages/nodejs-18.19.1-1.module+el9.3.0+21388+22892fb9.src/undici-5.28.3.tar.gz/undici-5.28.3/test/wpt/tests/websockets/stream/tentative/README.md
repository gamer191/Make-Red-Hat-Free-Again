# WebSocketStream tentative tests

Tests in this directory are for the proposed "WebSocketStream" interface to the
WebSocket protocol. This is not yet standardised and browsers should not be
expected to pass these tests.

See the explainer at
https://github.com/ricea/websocketstream-explainer/blob/master/README.md for
more information about the API.
