### Service file for rtslib-fb use with systemd

The systemd developers encourage upstream projects to ship and install
a service file, saving each systemd-based distribution from having to
create one.

In this directory is the systemd service file for rtslib-fb. However,
it is not currently installed by default.
