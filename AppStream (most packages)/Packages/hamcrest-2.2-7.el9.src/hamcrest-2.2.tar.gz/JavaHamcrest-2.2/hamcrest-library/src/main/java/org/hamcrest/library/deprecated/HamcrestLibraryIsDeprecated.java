package org.hamcrest.library.deprecated;

/**
 * All the classes in <code>hamcrest-library.jar</code> have moved to
 * <code>hamcrest.jar</code>. Please use that dependency instead.
 */
@Deprecated
class HamcrestLibraryIsDeprecated {
}
