/**
 * All classes in <code>hamcrest-library.jar</code> have been migrated to
 * <code>hamcrest.jar</code>. Please use that dependency instead.
 */
package org.hamcrest.library.deprecated;