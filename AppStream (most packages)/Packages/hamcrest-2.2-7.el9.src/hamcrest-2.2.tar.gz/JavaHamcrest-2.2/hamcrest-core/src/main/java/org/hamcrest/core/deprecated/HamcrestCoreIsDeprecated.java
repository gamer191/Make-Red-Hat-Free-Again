package org.hamcrest.core.deprecated;

/**
 * All the classes in <code>hamcrest-core.jar</code> have moved to
 * <code>hamcrest.jar</code>. Please use that dependency instead.
 */
@Deprecated
class HamcrestCoreIsDeprecated {
}
