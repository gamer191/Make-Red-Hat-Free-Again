/**
 * All classes in <code>hamcrest-core.jar</code> have been migrated to
 * <code>hamcrest.jar</code>. Please use that dependency instead.
 */
package org.hamcrest.core.deprecated;