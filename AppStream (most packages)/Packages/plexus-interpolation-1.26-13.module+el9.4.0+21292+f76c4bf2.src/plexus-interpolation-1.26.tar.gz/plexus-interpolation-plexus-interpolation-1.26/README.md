Plexus-Interpolation
===============

[![Build Status](https://travis-ci.org/codehaus-plexus/plexus-interpolation.svg?branch=master)](https://travis-ci.org/codehaus-plexus/plexus-interpolation)
[![Maven Central](https://img.shields.io/maven-central/v/org.codehaus.plexus/plexus-interpolation.svg?label=Maven%20Central)](https://search.maven.org/#search%7Cgav%7C1%7Cg%3A%22org.codehaus.plexus%22%20AND%20a%3A%22plexus-interpolation%22)

The current master is now at https://github.com/codehaus-plexus/plexus-interpolation

Components for interpolating `${}` strings and the like.

For publishing [the site](https://codehaus-plexus.github.io/plexus-interpolation/) do the following:

```
mvn -Preporting verify site-deploy
```

