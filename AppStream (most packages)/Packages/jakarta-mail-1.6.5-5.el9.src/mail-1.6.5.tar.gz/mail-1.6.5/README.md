See the [Jakarta Mail web site](https://eclipse-ee4j.github.io/mail).
