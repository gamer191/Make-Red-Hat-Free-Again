==================
stas-config.target
==================
.. module:: stas-config.target

.. include:: _stas-config.target.rst

