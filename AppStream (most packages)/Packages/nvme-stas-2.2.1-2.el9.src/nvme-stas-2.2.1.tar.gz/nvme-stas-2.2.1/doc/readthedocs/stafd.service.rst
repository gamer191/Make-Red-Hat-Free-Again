=============
stafd.service
=============
.. module:: stafd.service

.. include:: _stafd.service.rst

