=======
stasadm
=======
.. module:: stasadm

.. include:: _stasadm.rst

