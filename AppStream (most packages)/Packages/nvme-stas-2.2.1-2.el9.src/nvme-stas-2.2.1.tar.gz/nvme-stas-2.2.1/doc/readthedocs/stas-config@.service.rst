====================
stas-config@.service
====================
.. module:: stas-config@.service

.. include:: _stas-config@.service.rst

