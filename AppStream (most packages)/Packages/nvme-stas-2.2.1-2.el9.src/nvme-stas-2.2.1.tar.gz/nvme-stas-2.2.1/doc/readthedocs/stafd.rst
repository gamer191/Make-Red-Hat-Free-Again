=====
stafd
=====
.. module:: stafd

.. include:: _stafd.rst

