package perf;

class Value {
    public int x, y;
    
    public Value() { }
    public Value(int x, int y) {
        this.x = x;
        this.y = y;
    }
}