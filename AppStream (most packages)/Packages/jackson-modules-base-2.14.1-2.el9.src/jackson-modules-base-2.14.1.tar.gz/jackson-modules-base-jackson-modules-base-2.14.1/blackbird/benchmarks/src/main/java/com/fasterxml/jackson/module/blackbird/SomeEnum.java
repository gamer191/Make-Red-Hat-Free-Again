package com.fasterxml.jackson.module.blackbird;

public enum SomeEnum {
    EA, EB, EC, ED
}