---
layout: manual
Content-Style: 'text/css'
title: _MP(PMEMPOOL-CONVERT, 1)
collection: pmempool
header: PMDK
date: pmem Tools version 1.4
...

[comment]: <> (SPDX-License-Identifier: BSD-3-Clause)
[comment]: <> (Copyright 2016-2018, Intel Corporation)

[comment]: <> (pmempool-convert.1 -- man page for pmempool-convert)

[NAME](#name)<br />
[SYNOPSIS](#synopsis)<br />
[DESCRIPTION](#description)<br />
[EXAMPLE](#example)<br />
[SEE ALSO](#see-also)<br />

# NAME #

**pmempool-convert** - this is a wrapper around pmdk-convert tool. More information
can be found in **pmdk-convert**(1) man page.

# SEE ALSO #

**pmdk-convert**(1), **pmempool**(1), **libpmemblk**(7), **libpmemlog**(7),
**libpmemobj**(7), **libpmempool**(7) and **<https://pmem.io>**
