/* SPDX-License-Identifier: BSD-3-Clause */
/* Copyright 2017-2020, Intel Corporation */

/*
 * sys/sysmacros.h -- Empty file redirect
 */
