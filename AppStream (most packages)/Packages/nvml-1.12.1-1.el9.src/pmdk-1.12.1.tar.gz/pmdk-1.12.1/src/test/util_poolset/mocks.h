/* SPDX-License-Identifier: BSD-3-Clause */
/* Copyright 2015-2020, Intel Corporation */

#ifndef MOCKS_H
#define MOCKS_H

extern const char *Open_path;
extern os_off_t Fallocate_len;
extern size_t Is_pmem_len;

#endif
