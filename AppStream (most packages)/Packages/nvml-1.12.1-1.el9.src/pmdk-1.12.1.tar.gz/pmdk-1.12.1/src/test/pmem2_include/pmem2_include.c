// SPDX-License-Identifier: BSD-3-Clause
/* Copyright 2019, Intel Corporation */

/*
 * pmem2_include.c -- include test for libpmem2
 *
 * this is only a compilation test - do not run this program
 */

#include <libpmem2.h>

int
main(int argc, char *argv[])
{
	return 0;
}
