// SPDX-License-Identifier: BSD-3-Clause
/* Copyright 2016, Intel Corporation */

/*
 * obj_atomic_base_include.c -- include test for libpmemobj
 */

#include <libpmemobj/atomic_base.h>
