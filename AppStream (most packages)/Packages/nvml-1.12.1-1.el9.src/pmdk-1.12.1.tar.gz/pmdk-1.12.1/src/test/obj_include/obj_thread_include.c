// SPDX-License-Identifier: BSD-3-Clause
/* Copyright 2016, Intel Corporation */

/*
 * obj_thread_include.c -- include test for libpmemobj
 */

#include <libpmemobj/thread.h>
