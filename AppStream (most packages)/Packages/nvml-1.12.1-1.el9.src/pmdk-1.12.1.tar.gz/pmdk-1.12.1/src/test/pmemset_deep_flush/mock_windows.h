/* SPDX-License-Identifier: BSD-3-Clause */
/* Copyright 2021, Intel Corporation */

#ifndef WRAP_REAL
#define pmem2_deep_flush __wrap_pmem2_deep_flush
#endif
