<!-- If you are filing this issue with a regular release please try master as it might already be fixed. -->

- PipeWire version (`pipewire --version`):
- Distribution and distribution version (`PRETTY_NAME` from `/etc/os-release`):
- Desktop Environment:
- Kernel version (`uname -r`):

## Description of Problem:


## How Reproducible:


### Steps to Reproduce:

 1.
 2.
 3.


### Actual Results:


### Expected Results:


# Additional Info (as attachments):

 - `pw-dump > pw-dump.log`:
