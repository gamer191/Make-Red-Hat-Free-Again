---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

**What enhancement are you suggesting for the Vulkan Loader?  Please describe in detail. **
Description

**Is this specific to a single platform?**
OS platform

**Additional context**
