package org.codehaus.plexus.component.manager;

/** @author Jason van Zyl */
public class DefaultComponent
    implements Component
{
}
