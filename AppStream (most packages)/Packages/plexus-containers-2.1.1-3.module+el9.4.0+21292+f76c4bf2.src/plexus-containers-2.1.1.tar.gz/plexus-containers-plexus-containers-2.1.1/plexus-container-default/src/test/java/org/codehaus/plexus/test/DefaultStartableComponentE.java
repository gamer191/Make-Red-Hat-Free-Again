package org.codehaus.plexus.test;

public class DefaultStartableComponentE
    extends AbstractStartableComponent
{
}
