package org.codehaus.plexus.components;

public interface C
{
   public void hello();
}
