package org.codehaus.plexus.test;

public interface CircularComponent
{
    static String ROLE = CircularComponent.class.getName();
}