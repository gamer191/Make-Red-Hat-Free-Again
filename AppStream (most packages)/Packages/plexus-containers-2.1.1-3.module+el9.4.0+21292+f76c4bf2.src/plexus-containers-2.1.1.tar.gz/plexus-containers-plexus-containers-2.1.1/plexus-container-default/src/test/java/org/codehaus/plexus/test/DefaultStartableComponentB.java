package org.codehaus.plexus.test;

public class DefaultStartableComponentB
    extends AbstractStartableComponent
{
}
