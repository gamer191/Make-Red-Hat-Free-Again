package org.codehaus.plexus.components;

public interface A
{
   public void hello();
}
