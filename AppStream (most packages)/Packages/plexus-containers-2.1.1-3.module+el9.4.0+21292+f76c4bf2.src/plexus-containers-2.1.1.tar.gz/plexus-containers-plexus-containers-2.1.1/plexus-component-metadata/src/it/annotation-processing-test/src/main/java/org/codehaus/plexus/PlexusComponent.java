package org.codehaus.plexus;

public interface PlexusComponent
{
    String execute();
}
