#ifndef TESTSUITE_ARGUMENTS_H
#define TESTSUITE_ARGUMENTS_H

extern const struct sieve_argument_def testsuite_string_argument;

#endif
