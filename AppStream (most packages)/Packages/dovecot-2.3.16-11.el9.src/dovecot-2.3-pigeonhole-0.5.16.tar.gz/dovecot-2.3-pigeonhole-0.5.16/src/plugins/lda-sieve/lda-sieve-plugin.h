#ifndef LDA_SIEVE_PLUGIN_H
#define LDA_SIEVE_PLUGIN_H

/*
 * Plugin interface
 */

void sieve_plugin_init(void);
void sieve_plugin_deinit(void);

#endif
