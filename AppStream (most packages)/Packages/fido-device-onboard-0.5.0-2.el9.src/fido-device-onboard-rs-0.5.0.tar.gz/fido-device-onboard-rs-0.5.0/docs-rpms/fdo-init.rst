==============
FDO-INIT
==============

dracut module for device initialization.

Please visit https://github.com/fedora-iot/fido-device-onboard-rs
