=====================
FDO-RENDEZVOUS-SERVER
=====================

FDO Rendezvous Server implementation.

Please visit https://github.com/fedora-iot/fido-device-onboard-rs
