==========
FDO-CLIENT
==========

FDO Client implementation.

Please visit https://github.com/fedora-iot/fido-device-onboard-rs
