---
layout: home
title: Home
---

## FIDO Device Onboarding Rust

This is an open source implementation of the [FIDO Device Onboard Specification](https://fidoalliance.org/specs/FDO/fido-device-onboard-v1.0-ps-20210323/fido-device-onboard-v1.0-ps-20210323.html), written in Rust.
