DROP TABLE manufacturer_vouchers;
