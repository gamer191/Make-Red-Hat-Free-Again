DROP TABLE owner_vouchers;
