-- This file should undo anything in `up.sql`

DROP TABLE rendezvous_vouchers;
