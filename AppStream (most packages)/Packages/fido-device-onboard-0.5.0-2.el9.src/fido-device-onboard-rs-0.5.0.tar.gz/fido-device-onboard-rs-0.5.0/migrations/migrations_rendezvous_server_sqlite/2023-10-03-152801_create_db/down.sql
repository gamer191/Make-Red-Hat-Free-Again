DROP TABLE rendezvous_vouchers;
