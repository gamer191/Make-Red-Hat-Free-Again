package libfdo_data

// #cgo LDFLAGS: -lfdo_data
// #include <libfdo-data/fdo_data.h>
import "C"
