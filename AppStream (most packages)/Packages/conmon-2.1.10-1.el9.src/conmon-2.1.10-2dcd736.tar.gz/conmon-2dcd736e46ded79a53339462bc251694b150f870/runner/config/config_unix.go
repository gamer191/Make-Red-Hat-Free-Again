//go:build !windows

package config

const (
	ContainerAttachSocketDir = "/var/run/crio"
)
