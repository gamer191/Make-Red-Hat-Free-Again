//go:build windows

package config

const (
	ContainerAttachSocketDir = "C:\\crio\\run\\"
)
