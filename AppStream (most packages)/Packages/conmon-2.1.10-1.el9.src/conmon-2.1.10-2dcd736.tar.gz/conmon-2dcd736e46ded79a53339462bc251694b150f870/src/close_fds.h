void close_other_fds();
void close_all_fds_ge_than(int firstfd);
