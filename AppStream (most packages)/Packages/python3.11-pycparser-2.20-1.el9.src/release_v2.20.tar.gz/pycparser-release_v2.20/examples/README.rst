Run these examples from the root directory of pycparser.

Please note that most realistic C code samples would require running the C
preprocessor before passing the code to **pycparser**; see the `README file
<https://github.com/eliben/pycparser/blob/master/README.rst>`_ and
`this blog post
<https://eli.thegreenplace.net/2015/on-parsing-c-type-declarations-and-fake-headers>`_
more details.
