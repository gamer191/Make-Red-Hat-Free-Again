int test() {
    int a = 0;
    return a;
}
