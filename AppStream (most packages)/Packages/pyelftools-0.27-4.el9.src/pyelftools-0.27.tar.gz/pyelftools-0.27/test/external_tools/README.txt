Some utilities that use libelf to create synthetic ELF files

Also, readelf picked up from a built binutils. Run it with --version to version
details. The binary is built on a 64-bit Ubuntu machine.
