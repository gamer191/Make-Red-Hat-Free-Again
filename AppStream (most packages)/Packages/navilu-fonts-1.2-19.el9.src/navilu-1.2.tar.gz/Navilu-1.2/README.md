# tar.gz for fedora packaging

    make fedora
    
Source and Binary tar.gz will be created in the /tmp/ directory. Ex: navilu-1.2.tar.gz  navilu-ttf-1.2.tar.gz

# Generate Font

    make
    
ttf file will be created, copy to ~/.fonts directory and run fc-cache

# Download Font and Install

Download ttf font and install by copying to fonts directory. (~/.fonts/ in Linux)
