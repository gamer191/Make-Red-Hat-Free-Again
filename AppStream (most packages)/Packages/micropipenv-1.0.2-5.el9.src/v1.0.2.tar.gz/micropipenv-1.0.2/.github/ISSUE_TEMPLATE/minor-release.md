---
name: Minor release
about: Create a new minor release
title: New minor release
assignees: ''

---

Hey, Kebechet!

Create a new minor release, please.
