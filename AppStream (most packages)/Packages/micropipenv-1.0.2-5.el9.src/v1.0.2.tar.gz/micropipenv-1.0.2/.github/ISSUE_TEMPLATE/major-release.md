---
name: Major release
about: Create a new major release
title: New major release
assignees: ''

---

Hey, Kebechet!

Create a new major release, please.
