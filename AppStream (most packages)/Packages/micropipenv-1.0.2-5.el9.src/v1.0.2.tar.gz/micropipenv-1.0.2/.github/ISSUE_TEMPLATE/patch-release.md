---
name: Patch release
about: Create a new patch release
title: New patch release
assignees: ''

---

Hey, Kebechet!

Create a new patch release, please.
