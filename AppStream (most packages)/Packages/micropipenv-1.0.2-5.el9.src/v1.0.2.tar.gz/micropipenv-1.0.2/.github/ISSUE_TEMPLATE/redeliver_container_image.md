---
name: Deliver Container Image
about: build a git tag and push it as a container image to quay
title: Deliver Container Image
assignees: sesheta
labels: bot
---

Hey, AICoE-CI!

Please build and deliver the following git tag:

Tag: x.y.z
