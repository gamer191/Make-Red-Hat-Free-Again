char _freemem[]="freemem";
char _totalmem[]="totalmem";
char _freeswap[]="freeswap";
char _totalswap[]="totalswap";
