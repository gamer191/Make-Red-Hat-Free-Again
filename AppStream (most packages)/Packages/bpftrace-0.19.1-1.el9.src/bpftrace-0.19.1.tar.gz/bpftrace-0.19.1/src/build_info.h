#pragma once

#include <string>

namespace bpftrace {

class BuildInfo
{
public:
  static std::string report();
};

} // namespace bpftrace
