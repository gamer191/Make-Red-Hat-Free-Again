void print(char * a, char * b)
{
  (void) a;
  (void) b;
}

int main(void)
{
  char sa[] = "hello";
  char sb[] = "world";
  print(sa, sb);
}
