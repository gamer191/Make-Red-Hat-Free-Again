int __attribute__((noinline)) fn$()
{
  return 0;
}

int main(void)
{
  return fn$();
}
