import pkg_resources

__version__ = pkg_resources.get_distribution('keycloak-httpd-client-install').version
