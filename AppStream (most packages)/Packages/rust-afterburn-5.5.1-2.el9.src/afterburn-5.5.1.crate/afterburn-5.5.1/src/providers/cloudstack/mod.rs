//! Metadata fetchers for the cloudstack provider

pub mod configdrive;
#[cfg(test)]
mod mock_tests;
pub mod network;
