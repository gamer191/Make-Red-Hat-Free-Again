---
nav_order: 2
has_children: true
has_toc: false
---

# Usage

## Initrd first-boot network arguments

See [Initrd first-boot network arguments](usage/initrd-network-cmdline.md).

## VMware Netplan guestinfo metadata

See [VMware Netplan guestinfo metadata](usage/vmware-netplan-guestinfo-metadata.md).

## Metadata attributes

See [Metadata attributes](usage/attributes.md).
