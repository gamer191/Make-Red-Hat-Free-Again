#!/bin/bash

#SPDX-License-Identifier: Apache-2.0
#Copyright 2021 Keylime Authors

echo "Hello from non-python payload action!"
