API documentation
=================
.. automodule:: pyrsistent
   :members:
