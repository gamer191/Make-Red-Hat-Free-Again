#!/usr/bin/env bash

kextunload /Library/Extensions/PcmMsrDriver.kext
rm -rf /Library/Extensions/PcmMsrDriver.kext
