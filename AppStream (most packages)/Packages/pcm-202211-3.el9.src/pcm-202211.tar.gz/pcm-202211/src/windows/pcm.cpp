// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) 2009-2011, Intel Corporation

// pcm.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "../pcm.cpp"
