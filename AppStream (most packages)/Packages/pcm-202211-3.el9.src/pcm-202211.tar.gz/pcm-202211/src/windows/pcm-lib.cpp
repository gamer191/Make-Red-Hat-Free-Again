// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) 2009-2012, Intel Corporation

/* 
** Written by Otto Bruggeman
*/

// pcm-lib.cpp : Defines the exported functions for the DLL application.
//


#include "pcm-lib.h"


