#pragma once

#ifdef __GNUC__
    #if __GNUC__ < 7
        #define PCM_GCC_6_OR_BELOW
    #endif
#endif
