
kill `cat pcm.pid`
