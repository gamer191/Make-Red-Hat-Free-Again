#define IPC_STAT 0x102
