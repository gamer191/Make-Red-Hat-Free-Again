// We compile a plain crt1.o for toolchain compatibility, but it's
// identical to crt1-command.o.
#include "crt1-command.c"
