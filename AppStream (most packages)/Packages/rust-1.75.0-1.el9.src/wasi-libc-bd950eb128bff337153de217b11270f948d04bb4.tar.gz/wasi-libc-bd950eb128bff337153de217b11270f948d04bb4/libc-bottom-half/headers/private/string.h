#include_next <string.h>
#include <_/cdefs.h>
