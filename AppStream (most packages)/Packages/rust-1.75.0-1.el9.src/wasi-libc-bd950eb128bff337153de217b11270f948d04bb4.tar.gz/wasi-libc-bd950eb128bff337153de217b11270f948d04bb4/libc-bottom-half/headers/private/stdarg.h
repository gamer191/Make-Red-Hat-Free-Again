#include_next <stdarg.h>
#include <_/cdefs.h>
