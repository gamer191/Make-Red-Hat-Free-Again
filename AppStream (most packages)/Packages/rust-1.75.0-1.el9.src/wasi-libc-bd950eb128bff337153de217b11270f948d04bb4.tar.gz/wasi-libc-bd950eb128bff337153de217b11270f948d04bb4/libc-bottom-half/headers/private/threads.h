#ifndef __cplusplus
#define thread_local _Thread_local
#endif
