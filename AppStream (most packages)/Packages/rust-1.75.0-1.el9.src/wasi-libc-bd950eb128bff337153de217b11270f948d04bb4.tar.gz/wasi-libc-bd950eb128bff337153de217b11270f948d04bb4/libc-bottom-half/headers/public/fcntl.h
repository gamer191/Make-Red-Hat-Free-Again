#ifndef __wasilibc_fcntl_h
#define __wasilibc_fcntl_h

/*
 * Include the real implementation, which is factored into a separate file so
 * that it can be reused by other libc fcntl implementations.
 */
#include <__header_fcntl.h>

#endif
