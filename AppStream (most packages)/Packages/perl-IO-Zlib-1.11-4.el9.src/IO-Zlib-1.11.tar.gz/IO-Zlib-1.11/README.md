[![Build Status](https://travis-ci.org/tomhughes/IO-Zlib.svg?branch=master)](https://travis-ci.org/tomhughes/IO-Zlib)

This is the IO::Zlib module package for perl5.

This modules provides an IO:: style interface to the Compress::Zlib
package. The main advantage is that you can use an IO::Zlib object
in much the same way as an IO::File object so you can have common
code that doesn't know which sort of file it is using.

After unpacking the distribution, to install this module type

        perl Makefile.PL
        make
        make test
        make install

Please report any bugs/suggestions to <tom@compton.nu>.

Copyright (c) Tom Hughes <tom@compton.nu>.

All rights reserved. This program is free software; you can
redistribute it and/or modify it under the same terms as Perl itself.
