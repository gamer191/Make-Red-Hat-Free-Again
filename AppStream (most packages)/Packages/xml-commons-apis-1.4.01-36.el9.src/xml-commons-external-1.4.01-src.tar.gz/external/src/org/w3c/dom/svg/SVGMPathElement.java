
package org.w3c.dom.svg;

public interface SVGMPathElement extends 
               SVGElement,
               SVGURIReference,
               SVGExternalResourcesRequired {
}
