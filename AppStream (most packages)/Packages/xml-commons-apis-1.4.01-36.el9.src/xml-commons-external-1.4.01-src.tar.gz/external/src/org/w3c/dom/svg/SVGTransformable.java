
package org.w3c.dom.svg;

public interface SVGTransformable extends 
               SVGLocatable {
  public SVGAnimatedTransformList getTransform( );
}
