
package org.w3c.dom.svg;

public interface SVGAnimatedLength {
  public SVGLength getBaseVal( );
  public SVGLength getAnimVal( );
}
