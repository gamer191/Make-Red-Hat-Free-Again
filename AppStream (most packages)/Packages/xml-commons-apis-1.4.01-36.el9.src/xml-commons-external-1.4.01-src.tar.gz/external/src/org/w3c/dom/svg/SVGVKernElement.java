
package org.w3c.dom.svg;

public interface SVGVKernElement extends 
               SVGElement {
}
