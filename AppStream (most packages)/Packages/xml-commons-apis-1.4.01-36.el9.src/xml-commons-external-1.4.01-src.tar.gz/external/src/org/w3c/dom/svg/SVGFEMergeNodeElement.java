
package org.w3c.dom.svg;

public interface SVGFEMergeNodeElement extends 
               SVGElement {
  public SVGAnimatedString getIn1( );
}
