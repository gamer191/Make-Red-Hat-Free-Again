# Jakarta Activation

Jakarta Activation lets you take advantage of standard services to:
determine the type of an arbitrary piece of data; encapsulate access to
it; discover the operations available on it; and instantiate the
appropriate bean to perform the operation(s).

See the
[Jakarta Activation web site](https://eclipse-ee4j.github.io/jaf/).
