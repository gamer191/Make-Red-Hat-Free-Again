`CLIENT UNPAUSE` is used to resume command processing for all clients that were paused by `CLIENT PAUSE`.

@return

@simple-string-reply: The command returns `OK`
