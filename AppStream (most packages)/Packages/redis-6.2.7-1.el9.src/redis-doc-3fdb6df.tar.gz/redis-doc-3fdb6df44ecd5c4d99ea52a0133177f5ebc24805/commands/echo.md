Returns `message`.

@return

@bulk-string-reply

@examples

```cli
ECHO "Hello World!"
```
