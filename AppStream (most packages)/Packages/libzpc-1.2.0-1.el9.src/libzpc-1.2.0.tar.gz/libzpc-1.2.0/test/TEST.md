test
===

testlib
---
Functions used by multiple test suites.

b_*test*
---
Simple build tests.

t_*testsuite*
---
Test suites using the googletest framework. Part of the test program.
