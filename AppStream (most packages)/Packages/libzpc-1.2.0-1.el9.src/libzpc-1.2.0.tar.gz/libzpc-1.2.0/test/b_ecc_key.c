/*
 * Copyright IBM Corp. 2022
 *
 * libzpc is free software; you can redistribute it and/or modify
 * it under the terms of the MIT license. See LICENSE for details.
 */

/*
 * Build test for ecc_key.h.
 */
#include "zpc/ecc_key.h"
#include "zpc/ecc_key.h"

int b_ecc_key_not_empty;
