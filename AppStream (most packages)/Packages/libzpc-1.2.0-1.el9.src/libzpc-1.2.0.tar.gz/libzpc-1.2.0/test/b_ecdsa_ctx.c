/*
 * Copyright IBM Corp. 2022
 *
 * libzpc is free software; you can redistribute it and/or modify
 * it under the terms of the MIT license. See LICENSE for details.
 */

/*
 * Build test for ecdsa_ctx.h.
 */
#include "zpc/ecdsa_ctx.h"
#include "zpc/ecdsa_ctx.h"

int b_ecdsa_ctx_not_empty;
