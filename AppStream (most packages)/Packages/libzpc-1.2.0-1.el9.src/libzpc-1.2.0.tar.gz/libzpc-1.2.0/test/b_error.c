/*
 * Copyright IBM Corp. 2021
 *
 * libzpc is free software; you can redistribute it and/or modify
 * it under the terms of the MIT license. See LICENSE for details.
 */

/*
 * Build test for error.h.
 */
#include "zpc/error.h"
#include "zpc/error.h"

int b_error_not_empty;
