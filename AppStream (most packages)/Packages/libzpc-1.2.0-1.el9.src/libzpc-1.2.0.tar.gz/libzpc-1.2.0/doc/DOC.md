doc
===

UMLet
---
The `.uxf` (UMLet diagram format) files can be edited with the UMLet tool and exported to other format like `.eps` or `.jpg`.
