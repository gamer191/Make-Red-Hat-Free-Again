#!/bin/bash

source ./k8s/kubevirtci.sh
kubevirtci::kubeconfig
