// SPDX-License-Identifier: Apache-2.0

use super::super::{NmSettingVrf, ToKeyfile};

impl ToKeyfile for NmSettingVrf {}
