#!/bin/bash

set -eo pipefail

make tests
