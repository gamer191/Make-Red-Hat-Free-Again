"""Version of PodmanPy."""

__version__ = "4.9.0"
__compatible_version__ = "1.40"
