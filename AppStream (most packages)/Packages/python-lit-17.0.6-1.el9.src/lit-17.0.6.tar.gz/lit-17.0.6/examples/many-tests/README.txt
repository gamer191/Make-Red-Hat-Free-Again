========================
 Many Tests lit Example
========================

This directory contains a trivial lit test suite configuration that defines a
custom test format which just generates a large (N=10000) number of tests that
do a small amount of work in the Python test execution code.

This test suite is useful for testing the performance of lit on large numbers of
tests.
