# RUN: echo %rec5
