#!/usr/bin/env python

import print_environment

print_environment.execute()
