#!/usr/bin/env python

raise SystemExit("We are not a valid gtest executable!")
