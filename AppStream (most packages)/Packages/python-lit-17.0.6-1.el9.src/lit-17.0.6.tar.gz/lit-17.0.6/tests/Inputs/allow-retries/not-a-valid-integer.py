# ALLOW_RETRIES: not-an-integer

# RUN: true
