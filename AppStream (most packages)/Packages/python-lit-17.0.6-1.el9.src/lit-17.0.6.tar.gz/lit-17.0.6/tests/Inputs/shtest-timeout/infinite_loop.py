# RUN: %{python} %s
while True:
    pass
