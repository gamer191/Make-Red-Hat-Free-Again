# RUN: true

# Here is a string that cannot be decoded in line mode: �.
