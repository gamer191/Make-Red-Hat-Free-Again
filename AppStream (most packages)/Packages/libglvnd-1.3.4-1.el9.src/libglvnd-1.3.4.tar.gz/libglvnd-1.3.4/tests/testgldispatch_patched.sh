#!/bin/sh

set -e

./testgldispatch -s -g -p
./testgldispatch -s -g -p -l

