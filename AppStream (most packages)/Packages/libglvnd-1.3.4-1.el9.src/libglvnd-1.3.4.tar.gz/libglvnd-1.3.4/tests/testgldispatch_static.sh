#!/bin/sh

./testgldispatch -s

