This folder contained libpmemobj C++ bindings.
They have been moved to https://github.com/pmem/libpmemobj-cpp/tree/master/include/libpmemobj++/detail
