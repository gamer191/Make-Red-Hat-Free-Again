## Security and Disclosure Information Policy for the container-selinux Project

The container-selinux Project follows the [Security and Disclosure Information Policy](https://github.com/containers/common/blob/master/SECURITY.md) for the Containers Projects.

