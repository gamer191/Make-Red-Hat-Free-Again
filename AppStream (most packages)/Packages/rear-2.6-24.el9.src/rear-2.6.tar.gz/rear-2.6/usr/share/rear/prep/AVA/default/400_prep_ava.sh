#
# prepare stuff for AVA
#
COPY_AS_IS+=( "${COPY_AS_IS_AVA[@]}" )
COPY_AS_IS_EXCLUDE+=( "${COPY_AS_IS_EXCLUDE_AVA[@]}" )
PROGS+=( "${PROGS_AVA[@]}" )
