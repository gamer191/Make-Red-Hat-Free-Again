from poetry.core.exceptions import PoetryCoreException


class PyProjectException(PoetryCoreException):
    pass
