class PoetryCoreException(Exception):
    pass
