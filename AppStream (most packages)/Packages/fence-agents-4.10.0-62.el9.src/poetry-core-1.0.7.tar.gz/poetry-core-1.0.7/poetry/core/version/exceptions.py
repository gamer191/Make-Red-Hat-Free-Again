class InvalidVersion(ValueError):

    pass
