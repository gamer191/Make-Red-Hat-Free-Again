pyroute2.nftables
=================

PyRoute2 is a pure Python **netlink** library.

This module provides very basic nftables API.

links
=====

* Home: <https://github.com/svinota/pyroute2/>
* PyPI: <https://pypi.org/project/pyroute2/>
* Usage: <https://github.com/svinota/pyroute2/discussions/796>
