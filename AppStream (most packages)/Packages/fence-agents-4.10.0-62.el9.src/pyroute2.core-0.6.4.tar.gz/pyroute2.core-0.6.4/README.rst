pyroute2.core
=============

PyRoute2 is a pure Python **netlink** library.

This is the core package, it implements the netlink parser and several netlink
sockets, including RTNL (IPRoute), WireGuard, MPTCP etc.

links
=====

* Home: <https://github.com/svinota/pyroute2/>
* PyPI: <https://pypi.org/project/pyroute2/>
* Usage: <https://github.com/svinota/pyroute2/discussions/796>
