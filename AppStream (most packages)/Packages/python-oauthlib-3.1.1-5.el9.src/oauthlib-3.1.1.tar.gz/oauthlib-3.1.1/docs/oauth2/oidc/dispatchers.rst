Dispatchers
-----------

.. contents::
   :depth: 2

Authorization Request
^^^^^^^^^^^^^^^^^^^^^

.. autoclass:: oauthlib.openid.connect.core.grant_types.ImplicitTokenGrantDispatcher
    :members:
    :inherited-members:


.. autoclass:: oauthlib.openid.connect.core.grant_types.AuthorizationCodeGrantDispatcher
    :members:
    :inherited-members:

Token Request
^^^^^^^^^^^^^

.. autoclass:: oauthlib.openid.connect.core.grant_types.AuthorizationTokenGrantDispatcher
    :members:
    :inherited-members:
