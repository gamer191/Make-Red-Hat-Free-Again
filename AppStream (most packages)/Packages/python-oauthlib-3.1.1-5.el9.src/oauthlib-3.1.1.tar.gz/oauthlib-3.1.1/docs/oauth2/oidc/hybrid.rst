OpenID Hybrid
-------------

.. autoclass:: oauthlib.openid.connect.core.grant_types.HybridGrant
    :members:
    :inherited-members:
