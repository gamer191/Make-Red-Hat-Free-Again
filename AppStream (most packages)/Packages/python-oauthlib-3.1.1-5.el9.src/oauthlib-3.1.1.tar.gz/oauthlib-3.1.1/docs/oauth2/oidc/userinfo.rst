========================
OpenID UserInfo endpoint
========================

        
.. autoclass:: oauthlib.openid.connect.core.endpoints.userinfo.UserInfoEndpoint
    :members:
