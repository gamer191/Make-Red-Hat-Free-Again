MobileApplicationClient
-----------------------

.. autoclass:: oauthlib.oauth2.MobileApplicationClient
    :members:
