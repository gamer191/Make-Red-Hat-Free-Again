WebApplicationClient
--------------------

.. autoclass:: oauthlib.oauth2.WebApplicationClient
    :members:
