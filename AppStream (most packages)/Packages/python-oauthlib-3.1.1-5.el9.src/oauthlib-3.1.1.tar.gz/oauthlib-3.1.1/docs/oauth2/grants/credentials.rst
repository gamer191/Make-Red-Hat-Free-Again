Client Credentials Grant
------------------------

.. autoclass:: oauthlib.oauth2.ClientCredentialsGrant
    :members:
    :inherited-members:
