Implicit Grant
--------------

.. autoclass:: oauthlib.oauth2.ImplicitGrant
    :members:
    :inherited-members:
