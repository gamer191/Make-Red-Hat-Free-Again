#ifndef COMPEL_PLUGIN_STD_STD_H__
#define COMPEL_PLUGIN_STD_STD_H__

#include <compel/plugins.h>
#include <compel/plugins/std/syscall.h>
#include <compel/plugins/std/string.h>
#include <compel/plugins/std/infect.h>
#include <compel/plugins/std/fds.h>
#include <compel/plugins/std/log.h>

#endif /* COMPEL_PLUGIN_STD_STD_H__ */
