#ifndef COMPEL_HANDLE_ELF_H__
#define COMPEL_HANDLE_ELF_H__

#include "elf64-types.h"

#define arch_is_machine_supported(e_machine) (e_machine == EM_MIPS)

#endif /* COMPEL_HANDLE_ELF_H__ */
