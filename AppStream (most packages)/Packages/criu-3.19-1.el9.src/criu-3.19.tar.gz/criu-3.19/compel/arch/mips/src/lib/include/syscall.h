#ifndef __COMPEL_SYSCALL_H__
#define __COMPEL_SYSCALL_H__

#ifndef SIGSTKFLT
#define SIGSTKFLT 16
#endif
#endif
