from .coredump import coredump_generator
