#ifndef __CR_INC_ATOMIC_H__
#define __CR_INC_ATOMIC_H__
#include "common/asm/atomic.h"
#endif
