use strict;
use warnings;
package perlfaq;

our $VERSION = '5.20201107';

1;
