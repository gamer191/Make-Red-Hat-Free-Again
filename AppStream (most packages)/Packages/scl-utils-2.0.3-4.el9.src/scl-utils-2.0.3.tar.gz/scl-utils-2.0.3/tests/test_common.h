#include <stdbool.h>

bool compare_string_arrays(char *const *array1, char *const *array2);
