Add drop-in grub fragments into this directory to have
them be installed into the final config.

The filenames must end in `.cfg`.
