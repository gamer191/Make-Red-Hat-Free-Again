# News

## libi2cd v1.0.3

Improvements:
- Install pkg-config file by default

## libi2cd v1.0.2

Bug fixes:
- Minor cosmetic changes for consistency
- Fixed release notes generation

## libi2cd v1.0.1

Bug fixes:
- Fixed errno handling in i2cd_open()

## libi2cd v1.0

Initial release
