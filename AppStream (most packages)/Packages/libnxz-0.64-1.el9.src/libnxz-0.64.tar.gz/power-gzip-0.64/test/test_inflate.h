#include "test.h"

extern int run_case1();
extern int run_case2();
extern int run_case3();
extern int run_case4();
extern int run_case5();
extern int run_case6();
extern int run_case7();
extern int run_case8();
extern int run_case9();
extern int run_case9_1();

extern int run_case12();
extern int run_case13();
extern int run_case14();
extern int run_case15();
extern int run_case16();
extern int run_case17();
extern int run_case18();
extern int run_case19();
extern int run_case19_1();
