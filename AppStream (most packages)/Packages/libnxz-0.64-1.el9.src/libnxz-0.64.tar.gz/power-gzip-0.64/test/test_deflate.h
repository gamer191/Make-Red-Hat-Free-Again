#include "test.h"

extern int run_case1();
extern int run_case2();
extern int run_case2();
extern int run_case3();
extern int run_case3_1();
extern int run_case4();
extern int run_case5();
extern int run_case6();
extern int run_case7();
extern int run_case8();
extern int run_case8_1();
extern int run_case8_2();
extern int run_case8_3();
extern int run_case9();
extern int run_case10();
extern int run_case11();
extern int run_case12();
extern int run_case13();
extern int run_case14();
extern int run_case15();
extern int run_case21();
extern int run_case30();
extern int run_case31();
extern int run_case32();
extern int run_case33();
extern int run_case33_1();
extern int run_case34();
extern int run_case41();

