/* See https://www.python-ldap.org/ for details. */

#ifndef __h_functions_
#define __h_functions_

#include "common.h"
extern void LDAPinit_functions(PyObject *);

#endif /* __h_functions_ */
