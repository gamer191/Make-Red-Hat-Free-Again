
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <stdbool.h>

int main(int argc, char ** argv)
{
	printf("Stub\n");
	return 0;
}

