urlview
=======

Extract URLs from a text file and allow the user to select via a menu