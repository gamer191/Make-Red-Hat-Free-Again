---
nav_order: 1
---

# Butane

Butane (formerly the Fedora CoreOS Config Transpiler, FCCT) translates human readable Butane Configs
into machine readable [Ignition](https://coreos.github.io/ignition/) Configs. See the [getting
started](getting-started) guide for how to use Butane and the [configuration specifications](specs.md)
for everything Butane configs support.
