# Security Policy

To report a security issue, please disclose it at [security advisory](https://github.com/KhronosGroup/glslang/security/advisories/new).

This project is maintained by a team of volunteers on a reasonable-effort basis. As
such, please give us at least 90 days to work on a fix before public exposure.
