#define Py_LIMITED_API 0x03020000
#include <Python.h>
