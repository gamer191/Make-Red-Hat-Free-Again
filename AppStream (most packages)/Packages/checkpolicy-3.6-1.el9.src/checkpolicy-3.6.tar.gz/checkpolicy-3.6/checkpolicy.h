#ifndef _CHECKPOLICY_H_
#define _CHECKPOLICY_H_

extern unsigned int policyvers;

#endif
