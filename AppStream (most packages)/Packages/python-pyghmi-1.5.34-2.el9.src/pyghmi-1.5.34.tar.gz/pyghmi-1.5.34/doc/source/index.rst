
.. include:: ../../README

Documentation
=============

.. toctree::
  :maxdepth: 2

  install/index
  reference/index
  contributor/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
