Please first make sure you have looked at:

* Documentation: https://github.com/mkleehammer/pyodbc/wiki
* Other issues

### Environment

To diagnose, we usually need to know the following, including version numbers.  On Windows, be
sure to specify 32-bit Python or 64-bit:

- Python: 
- pyodbc: 
- OS: 
- DB:
- driver:

### Issue

Often it is easiest to describe your issue as "expected behavior" and "observed behavior".
