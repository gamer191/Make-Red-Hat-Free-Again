Version 1.0.0 - Anish Patil<apatil@redhat.com>
* In TRY Sequence of aff file contains characters that are used in building suggestions for misplaced words  and those are arranged by frequencies in underline dictionaries. TRY sequence was missing in aff files for Gujarati dictionaries.  
* Added Aff rules for Gujarati dictionary 

Gujarati Dictionary for OpenOffice.org

Maintained By:
Kartik Mistry <kartik dot mistry at gmail dot com>

Original Word List By:
Utkarsh Project volunteers <support at utkarsh dot org>

Copyright Terms: GPL

Wordlist URL: http://www.utkarsh.org/dictionary/
