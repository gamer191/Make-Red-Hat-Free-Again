PO File Support
===============

.. module:: babel.messages.pofile

The PO file support can read and write PO and POT files.  It reads them
into :class:`~babel.messages.catalog.Catalog` objects and also writes
catalogs out.

.. autofunction:: read_po

.. autofunction:: write_po
