#!/bin/bash
set -x

tox
