# modulemd_tools (python package)

Because `python3-libmodulemd` is not enough.

This package provides convenient functions for working with modulemd
YAML definitions. It is a place for sharing code among other tools
within this project. ~~It is also meant to be used as a dependency for
other tools, such as build-systems.~~ **It is not ready to be used by
other tools yet, be cautious.**
