.. _datasource_e24cloud:

E24Cloud
********

`E24Cloud`_ platform provides an AWS EC2 metadata service clone. It identifies
itself to guests using the DMI system-manufacturer
(:file:`/sys/class/dmi/id/sys_vendor`).

.. _E24Cloud: https://www.e24cloud.com/en/
