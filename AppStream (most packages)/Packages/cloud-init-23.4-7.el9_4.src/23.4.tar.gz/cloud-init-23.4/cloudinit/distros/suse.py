from cloudinit.distros import opensuse


class Distro(opensuse.Distro):
    pass
