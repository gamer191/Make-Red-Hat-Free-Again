====================
rpms -- RPM metadata
====================

.. automodule:: productmd.rpms


Classes
=======

.. autoclass:: productmd.rpms.Rpms
   :members:
   :inherited-members:
