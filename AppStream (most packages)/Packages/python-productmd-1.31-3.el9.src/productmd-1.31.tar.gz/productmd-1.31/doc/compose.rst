==========================================
compose -- Easy access to compose metadata
==========================================

.. automodule:: productmd.compose




Classes
=======

.. autoclass:: productmd.compose.Compose
    :members:
    :inherited-members:
