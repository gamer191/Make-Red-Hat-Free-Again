=======================================
discinfo -- Installation media metadata
=======================================

.. automodule:: productmd.discinfo


Classes
=======

.. autoclass:: productmd.discinfo.DiscInfo
   :members:
   :inherited-members:
