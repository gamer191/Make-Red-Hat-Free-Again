========================
images -- Image metadata
========================

.. automodule:: productmd.images
    :members:

Classes
=======

.. autoclass:: productmd.images.Images
   :members:
   :inherited-members:


.. autoclass:: productmd.images.Image
   :members:
   :inherited-members:
