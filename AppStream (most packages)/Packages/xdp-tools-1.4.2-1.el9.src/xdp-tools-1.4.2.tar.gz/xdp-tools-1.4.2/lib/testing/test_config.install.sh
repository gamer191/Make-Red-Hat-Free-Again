# Test config for having tools in $PATH - to be installed along with the
# test runners in /usr/share/xdp-tools

XDP_FILTER=xdp-filter
XDP_LOADER=xdp-loader
XDP_BENCH=xdp-bench
XDP_MONITOR=xdp-monitor
XDP_TRAFFICGEN=xdp-trafficgen
XDPDUMP=xdpdump
