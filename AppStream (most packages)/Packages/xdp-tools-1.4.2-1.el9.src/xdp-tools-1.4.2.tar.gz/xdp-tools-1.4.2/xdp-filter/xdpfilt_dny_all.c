/* SPDX-License-Identifier: GPL-2.0 */

#define FILT_MODE_DENY
#define FILT_MODE_ETHERNET
#define FILT_MODE_IPV4
#define FILT_MODE_IPV6
#define FILT_MODE_UDP
#define FILT_MODE_TCP
#define FUNCNAME xdpfilt_dny_all
#include "xdpfilt_prog.h"
