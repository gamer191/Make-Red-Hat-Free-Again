#ifndef __DMI_H__
#define __DMI_H__
int add_dmi_err(ulong adr);
void print_dmi_err(void);
void print_dmi_info(void);
void print_dmi_startup_info(void);
#endif
