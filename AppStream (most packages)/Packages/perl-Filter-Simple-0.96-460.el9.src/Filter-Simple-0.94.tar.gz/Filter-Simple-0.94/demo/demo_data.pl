use Demo_Data;

say "yes:\n", <DATA>;

print "say\n";

__DATA__
a
b
c
d
