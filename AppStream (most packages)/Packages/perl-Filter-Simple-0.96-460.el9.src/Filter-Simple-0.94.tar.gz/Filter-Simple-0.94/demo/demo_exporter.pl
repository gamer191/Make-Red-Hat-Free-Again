use Demo_Exporter 'bar';

bar;
dye "tee";
