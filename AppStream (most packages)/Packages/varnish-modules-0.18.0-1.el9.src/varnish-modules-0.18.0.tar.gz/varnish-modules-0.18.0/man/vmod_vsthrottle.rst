..
.. NB:  This file is machine generated, DO NOT EDIT!
..
.. Edit vmod.vcc and run make instead
..

===============
vmod_vsthrottle
===============

---------------
Throttling VMOD
---------------

:Manual section: 3

SYNOPSIS
========

import vsthrottle [from "path"] ;

$Event event_function
CONTENTS
========

* :ref:`func_is_denied`

.. _func_is_denied:

BOOL is_denied(STRING, INT, DURATION)
-------------------------------------

Prototype
	BOOL is_denied(STRING, INT, DURATION)
