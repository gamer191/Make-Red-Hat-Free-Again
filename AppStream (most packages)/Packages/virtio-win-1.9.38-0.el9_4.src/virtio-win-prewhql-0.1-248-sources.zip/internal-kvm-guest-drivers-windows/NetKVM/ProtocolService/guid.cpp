#include <initguid.h>
#include <windows.h>
#include <devpkey.h>
