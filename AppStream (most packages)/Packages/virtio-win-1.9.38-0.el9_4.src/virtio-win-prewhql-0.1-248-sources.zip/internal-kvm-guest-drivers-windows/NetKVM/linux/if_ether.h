#ifndef _IF_ETHER_H
#define _IF_ETHER_H

#define ETH_ALEN    6

#endif

