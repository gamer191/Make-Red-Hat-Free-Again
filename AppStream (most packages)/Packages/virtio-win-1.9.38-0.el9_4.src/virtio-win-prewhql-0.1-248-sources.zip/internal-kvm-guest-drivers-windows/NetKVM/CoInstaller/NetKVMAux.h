#pragma once

wstring NetKVMGetKeyPathFromKKEY(HKEY hKey);
