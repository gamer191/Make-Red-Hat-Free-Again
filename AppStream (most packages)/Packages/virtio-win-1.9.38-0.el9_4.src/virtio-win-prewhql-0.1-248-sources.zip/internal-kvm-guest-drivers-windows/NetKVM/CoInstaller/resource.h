//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by netco.rc
//
#define IDS_ROOTGROUPDESC               101
#define IDS_LOGICEXCEPTION              102
#define IDS_NODEVICESFOUND              103
#define IDS_CANNOTOPENKEY               104
#define IDS_SHOWCMDHELP                 105
#define IDS_SHOWDEVICESSHORT            106
#define IDS_SHOWDEVICESLONG             107
#define IDS_DEVICEIDX                   108
#define IDS_DEVICEID                    109
#define IDS_DEVICEDESC                  110
#define IDS_DEVICEFRNAME                111
#define IDS_DEVICELOCINFO               112
#define IDS_DEVICENUM                   113
#define IDS_DEVICEREGKEY                114
#define IDS_RESTARTDEVICE               115
#define IDS_RESTARTDEVICELONG           116
#define IDS_RESTARTINGDEVICE            117
#define IDS_DONE                        118
#define IDS_INDEXOUTOFRANGE             119
#define IDS_FAIL                        120
#define IDS_REBOOTREQUIRED              121
#define IDS_SHOWPARAMSSHORT             122
#define IDS_SHOWPARAMSLONG              123
#define IDS_SHOWPARAMINFOSHORT          124
#define IDS_SHOWPARAMINFOLONG           125
#define IDS_PARAMENUMVALUE              126
#define IDS_PARAMNUMMIN                 127
#define IDS_PARAMNUMMAX                 128
#define IDS_PARAMNUMSTEP                129
#define IDS_PARAMTEXTLIMIT              130
#define IDS_PARAMUPPERCASE              131
#define IDS_PARAMUNKNOWNPROP            132
#define IDS_PARAMTYPE                   133
#define IDS_PARAMENUM                   134
#define IDS_PARAMINT                    135
#define IDS_PARAMLONG                   136
#define IDS_PARAMTEXT                   137
#define IDS_PARAMUNKNOWN                138
#define IDS_GETPARAM                    139
#define IDS_GETPARAMLONG                140
#define IDS_SETPARAMLONG                141
#define IDS_SETPARAM                    142
#define IDS_LOCALONLY                   143

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
