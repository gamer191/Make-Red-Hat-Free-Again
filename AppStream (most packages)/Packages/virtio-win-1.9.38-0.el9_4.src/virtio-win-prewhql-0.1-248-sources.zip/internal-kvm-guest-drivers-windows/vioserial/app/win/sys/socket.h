#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <io.h>

#define	SOCK_STREAM	1		/* stream socket */
#define	AF_UNIX		1		/* local to host (pipes, portals) */

typedef size_t socklen_t;