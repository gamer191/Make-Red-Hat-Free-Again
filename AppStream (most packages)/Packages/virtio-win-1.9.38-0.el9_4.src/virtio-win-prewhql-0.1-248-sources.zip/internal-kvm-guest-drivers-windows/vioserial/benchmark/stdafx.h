#pragma once

#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include <algorithm>
#include <limits>
#include <memory>

// interferes with numeric_limits<T>::max
#undef max

#include "benchmark.h"
