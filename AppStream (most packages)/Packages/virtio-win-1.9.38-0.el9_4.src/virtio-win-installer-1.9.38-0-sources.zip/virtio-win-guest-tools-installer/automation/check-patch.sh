#!/bin/bash -ex

BREW_BUILD_TARGET="rhevm-4.4-rhel-8-candidate"
temp_git_repo_clone="https://code.engineering.redhat.com/gerrit/ci-junkyard"
temp_git_repo_push='ssh://code.engineering.redhat.com/ci-junkyard'
temp_git_repo_branch_name="${STD_CI_PROJECT}-${STD_CI_GIT_SHA:0:7}-$(date +%s)"

build_git_repo() {
    sources_path="$1"
    sources_to_exclude="$2"

    mkdir tmp_sources
    pushd tmp_sources
    git init --quiet
    cp -r "${sources_path}/3rdParty" .
    cp -r "${sources_path}/virtio-win-drivers-installer" .
    cp -r "${sources_path}/virtio-win-installers-bundler" .
    cp -r "${sources_path}/test" .
    cp -r "${sources_path}/virtio-win-guest-tools-installer.ini" .
    git add *
    git commit -m "uploading sources to the build"
    git push --quiet ${temp_git_repo_push} HEAD:${temp_git_repo_branch_name}
    popd
}

brew_build() {
    echo "CI refspec is: ${STD_CI_REFSPEC}"
    remote="git+${temp_git_repo_clone}#${temp_git_repo_revision}"
    brew win-build --scratch --wait \
        "${BREW_BUILD_TARGET}" \
        "${remote}"\
        rhev-inst-w2k8-is2012 | \
        tee build_output
}

archive_brew_artifacts() {
    task_id=$(cat build_output | grep closed | awk '{print $1}')
    rpm_list=$(brew taskinfo $task_id | grep .msi | \
        sed 's:/mnt/redhat:http\://download.eng.bos.redhat.com:')
    echo $rpm_list | xargs -n 1 -P 8 wget -q -P exported-artifacts/
}

sources_path="$PWD"
build_git_repo "$sources_path" "$sources_to_exclude"
temp_git_repo_revision="$(git ls-remote ${temp_git_repo_clone} ${temp_git_repo_branch_name}|awk '{print $1}')"
brew_build
archive_brew_artifacts
