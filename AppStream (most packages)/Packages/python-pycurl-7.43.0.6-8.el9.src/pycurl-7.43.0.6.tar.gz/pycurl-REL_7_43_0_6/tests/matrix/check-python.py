import zlib
import ssl

dict(zlib=zlib, ssl=ssl)
