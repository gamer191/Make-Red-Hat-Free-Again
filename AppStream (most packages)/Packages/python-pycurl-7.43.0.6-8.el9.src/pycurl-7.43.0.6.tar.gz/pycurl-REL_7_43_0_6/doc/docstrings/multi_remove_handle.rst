remove_handle(Curl object) -> None

Corresponds to `curl_multi_remove_handle`_ in libcurl. This method
removes an existing and valid Curl object from the CurlMulti object.

.. _curl_multi_remove_handle:
    https://curl.haxx.se/libcurl/c/curl_multi_remove_handle.html
