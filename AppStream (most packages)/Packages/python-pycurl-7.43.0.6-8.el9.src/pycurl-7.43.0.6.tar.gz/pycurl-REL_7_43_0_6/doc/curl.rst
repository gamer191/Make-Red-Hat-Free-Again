curl Module Functionality
=========================

.. automodule:: curl

High Level Curl Object
----------------------

.. autoclass:: curl.Curl
   :members:
