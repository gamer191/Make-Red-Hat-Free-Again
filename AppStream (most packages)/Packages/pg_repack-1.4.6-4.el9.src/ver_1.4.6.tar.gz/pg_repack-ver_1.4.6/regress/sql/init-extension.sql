SET client_min_messages = warning;
CREATE EXTENSION pg_repack;
RESET client_min_messages;
