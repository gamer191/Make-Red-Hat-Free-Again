/**
 Packages to support the CSS-style element selector.
 {@link org.jsoup.select.Selector Selector defines the query syntax.}
 */
package org.jsoup.select;
