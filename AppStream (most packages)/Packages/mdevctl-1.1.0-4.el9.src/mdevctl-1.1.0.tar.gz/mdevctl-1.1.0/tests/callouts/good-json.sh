#!/usr/bin/env bash
echo "[{\"attribute0\": \"VALUE\"}]"
