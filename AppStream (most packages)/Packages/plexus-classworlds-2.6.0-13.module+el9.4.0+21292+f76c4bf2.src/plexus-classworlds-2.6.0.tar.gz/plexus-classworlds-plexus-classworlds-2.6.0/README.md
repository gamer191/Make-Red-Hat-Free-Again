Plexus-Classworlds
===============

[![Apache License, Version 2.0, January 2004](https://img.shields.io/github/license/codehaus-plexus/plexus-classworlds.svg?label=License)](http://www.apache.org/licenses/)
[![Maven Central](https://img.shields.io/maven-central/v/org.codehaus.plexus/plexus-classworlds.svg?label=Maven%20Central)](http://search.maven.org/#search%7Cga%7C1%7Cg%3A%22org.codehaus.plexus%22%20a%3A%22plexus-classworlds%22)
[![Build Status](https://travis-ci.org/codehaus-plexus/plexus-classworlds.svg?branch=master)](https://travis-ci.org/codehaus-plexus/plexus-classworlds)

Current master is now at https://github.com/codehaus-plexus/plexus-classworlds
