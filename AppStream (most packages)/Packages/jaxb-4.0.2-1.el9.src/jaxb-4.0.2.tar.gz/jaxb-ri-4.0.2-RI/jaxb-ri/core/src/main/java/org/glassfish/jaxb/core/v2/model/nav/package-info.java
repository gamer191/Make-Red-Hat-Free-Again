/*
 * Copyright (c) 2017, 2021 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Distribution License v. 1.0, which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/**
 * Abstraction around the reflection library, to support various reflection models (such as java.lang.reflect and Annotation Processing).
 */
package org.glassfish.jaxb.core.v2.model.nav;
