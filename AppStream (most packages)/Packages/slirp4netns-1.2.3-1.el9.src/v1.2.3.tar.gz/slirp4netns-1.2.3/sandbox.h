/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef SLIRP4NETNS_SANDBOX_H
# define SLIRP4NETNS_SANDBOX_H
int create_sandbox();
#endif
