#!/bin/bash
set -euo pipefail

echo "This is a failing script"

exit 1
