#!/bin/bash

bats *.bats --print-output-on-failure --jobs 1
