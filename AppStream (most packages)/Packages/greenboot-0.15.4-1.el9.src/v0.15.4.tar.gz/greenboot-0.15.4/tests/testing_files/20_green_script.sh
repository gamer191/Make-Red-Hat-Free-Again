#!/bin/bash
set -euo pipefail

echo "This is run when the boot is successful"

exit 0
