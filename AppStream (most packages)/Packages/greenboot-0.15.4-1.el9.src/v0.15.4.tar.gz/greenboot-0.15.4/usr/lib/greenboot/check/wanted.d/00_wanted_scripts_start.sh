#!/bin/bash
set -euo pipefail

echo "Running greenboot Wanted Health Check Scripts"
