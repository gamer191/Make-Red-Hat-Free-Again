#!/bin/bash
set -euo pipefail

echo "Running greenboot Required Health Check Scripts"
