Pajek
=====
.. automodule:: networkx.readwrite.pajek
.. autosummary::
   :toctree: generated/

   read_pajek
   write_pajek
   parse_pajek
   generate_pajek
