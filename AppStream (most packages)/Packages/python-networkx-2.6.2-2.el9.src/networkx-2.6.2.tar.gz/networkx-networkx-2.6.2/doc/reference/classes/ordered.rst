.. _ordered:

============================================
Ordered Graphs---Consistently ordered graphs
============================================

.. automodule:: networkx.classes.ordered

.. currentmodule:: networkx
.. autoclass:: OrderedGraph
.. autoclass:: OrderedDiGraph
.. autoclass:: OrderedMultiGraph
.. autoclass:: OrderedMultiDiGraph
