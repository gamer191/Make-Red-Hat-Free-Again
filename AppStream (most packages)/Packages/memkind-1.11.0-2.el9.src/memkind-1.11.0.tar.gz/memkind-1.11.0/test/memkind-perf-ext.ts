/usr/share/mpss/test/memkind-dt/all_tests -a --gtest_filter=PerformanceTest.*
/usr/share/mpss/test/memkind-dt/allocator_perf_tool_tests -a --gtest_filter=HeapManagerInitPerfTest*:AllocPerformanceTest*
