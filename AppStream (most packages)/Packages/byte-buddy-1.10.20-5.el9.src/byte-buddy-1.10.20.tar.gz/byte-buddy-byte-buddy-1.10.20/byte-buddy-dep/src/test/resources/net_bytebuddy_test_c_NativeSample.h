#include <jni.h>
#ifndef _Included_net_bytebuddy_test_c_NativeSample
#define _Included_net_bytebuddy_test_c_NativeSample
#ifdef __cplusplus
extern "C" {
#endif
JNIEXPORT jint JNICALL Java_net_bytebuddy_test_c_NativeSample_foo
  (JNIEnv *, jobject, jint, jint);

#ifdef __cplusplus
}
#endif
#endif
