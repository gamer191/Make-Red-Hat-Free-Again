package net.bytebuddy.description.method;

class AbstractMethodDescriptionTestNoNestMate {
    /* same package but different class to avoid nest mate visibility rules */
}
