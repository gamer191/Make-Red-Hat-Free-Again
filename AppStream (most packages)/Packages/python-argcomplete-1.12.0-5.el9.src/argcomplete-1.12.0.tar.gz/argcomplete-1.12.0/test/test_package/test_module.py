# PYTHON_ARGCOMPLETE_OK
from test_package import main


if __name__ == '__main__':
    main()
