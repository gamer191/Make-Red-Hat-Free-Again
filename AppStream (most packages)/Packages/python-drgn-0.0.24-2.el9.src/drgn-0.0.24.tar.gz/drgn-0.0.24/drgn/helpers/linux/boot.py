# Copyright (c) Meta Platforms, Inc. and affiliates.
# SPDX-License-Identifier: LGPL-2.1-or-later

"""
Boot
----

The ``drgn.helpers.linux.boot`` module provides helpers for inspecting the
Linux kernel boot configuration.
"""

from _drgn import (
    _linux_helper_kaslr_offset as kaslr_offset,
    _linux_helper_pgtable_l5_enabled as pgtable_l5_enabled,
)

__all__ = (
    "kaslr_offset",
    "pgtable_l5_enabled",
)
