// Copyright (c) Meta Platforms, Inc. and affiliates.
// SPDX-License-Identifier: LGPL-2.1-or-later

#include "hash_table.h"

const uint8_t hash_table_empty_chunk_header[16] __attribute__((__aligned__(16)));
