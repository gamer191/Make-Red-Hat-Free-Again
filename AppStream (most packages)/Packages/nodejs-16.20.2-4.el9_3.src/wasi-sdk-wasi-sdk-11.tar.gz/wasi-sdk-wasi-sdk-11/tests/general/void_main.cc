#include <stdio.h>

int main(void) {
    puts("hello from C++ void main!");
    return 0;
}
