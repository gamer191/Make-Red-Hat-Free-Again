#include <iostream>

int main() {
    std::cout << "hello from C++ main with cout!" << std::endl;
    return 0;
}
