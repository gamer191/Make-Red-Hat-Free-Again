#include <assert.h>
#include <stdbool.h>

int main(void) {
    assert(true);
    return 0;
}
