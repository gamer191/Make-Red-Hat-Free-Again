import { request } from '../../'

async function exampleCode() {
  await request('http://localhost:3000/foo')
}
