# Code of Conduct

Undici is committed to upholding the Node.js Code of Conduct.

The Node.js Code of Conduct document can be found at
https://github.com/nodejs/admin/blob/main/CODE_OF_CONDUCT.md
