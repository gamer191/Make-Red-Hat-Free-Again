#!/bin/sh

exec ./mgen -a 0 -c 1 -t 10
