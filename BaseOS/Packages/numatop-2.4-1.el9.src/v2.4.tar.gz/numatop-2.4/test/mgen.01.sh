#!/bin/sh
exec ./mgen -a 1 -c 1 -t 10
