#ifndef IPTRAF_NG_CAPT_RECVMSG_H
#define IPTRAF_NG_CAPT_RECVMSG_H

int capt_setup_recvmsg(struct capt *capt);

#endif	/* IPTRAF_NG_CAPT_RECVMSG_H */
