#ifndef IPTRAF_NG_HOSTMON_H
#define IPTRAF_NG_HOSTMON_H

void convmacaddr(char *addr, char *result);
void hostmon(time_t facilitytime, char *ifptr);

#endif	/* IPTRAF_NG_HOSTMON_H */
