#ifndef IPTRAF_NG_CAPT_RECVMMSG_H
#define IPTRAF_NG_CAPT_RECVMMSG_H

int capt_setup_recvmmsg(struct capt *capt);

#endif	/* IPTRAF_NG_CAPT_RECVMMSG_H */
