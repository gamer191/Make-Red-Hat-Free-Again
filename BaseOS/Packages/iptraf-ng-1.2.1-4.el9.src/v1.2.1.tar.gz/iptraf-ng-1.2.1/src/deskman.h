#ifndef IPTRAF_NG_DESKMAN_H
#define IPTRAF_NG_DESKMAN_H

/*
   deskman.h - header file for deskman.c
 */

void draw_desktop(void);
void about(void);
void printipcerr(void);
void printkeyhelp(char *keytext, char *desc, WINDOW * win, int highattr,
		  int textattr);
void stdkeyhelp(WINDOW * win);
void sortkeyhelp(void);
void tabkeyhelp(WINDOW * win);
void scrollkeyhelp(void);
void stdexitkeyhelp(void);
void indicate(char *message);
void printlargenum(unsigned long long i, WINDOW * win);
void print_packet_drops(unsigned long count, WINDOW *win, int x);
void set_next_screen_update(struct timespec *next_screen_update, struct timespec *now);
void infobox(char *text, char *prompt);
void standardcolors(int color);
void show_sort_statwin(WINDOW **, PANEL **);

#endif	/* IPTRAF_NG_DESKMAN_H */
