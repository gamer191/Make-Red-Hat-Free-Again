#ifndef IPTRAF_NG_CAPT_MMAP_V2_H
#define IPTRAF_NG_CAPT_MMAP_V2_H

int capt_setup_mmap_v2(struct capt *capt);

#endif	/* IPTRAF_NG_CAPT_MMAP_V2_H */
