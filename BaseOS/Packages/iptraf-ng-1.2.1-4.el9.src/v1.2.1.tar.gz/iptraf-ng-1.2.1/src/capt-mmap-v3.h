#ifndef IPTRAF_NG_CAPT_MMAP_V3_H
#define IPTRAF_NG_CAPT_MMAP_V3_H

int capt_setup_mmap_v3(struct capt *capt);

#endif	/* IPTRAF_NG_CAPT_MMAP_V3_H */
