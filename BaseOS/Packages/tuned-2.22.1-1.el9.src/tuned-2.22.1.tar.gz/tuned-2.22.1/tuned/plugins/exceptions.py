import tuned.exceptions

class NotSupportedPluginException(tuned.exceptions.TunedException):
	pass
