#!/bin/bash

. /usr/lib/tuned/functions

start() {
    return 0
}

stop() {
    return 0
}

verify() {
    return 0
}

process $@
