#!/bin/bash
rm -f -- *.key *.crt *.crl
