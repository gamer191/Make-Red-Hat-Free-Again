#!/bin/sh

modprobe fuse
