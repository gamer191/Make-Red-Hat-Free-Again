# Jitter RNG Tests

The following Jitter RNG tests are available in the following
directories:

* `raw-entropy`: Gathering of the raw unprocessed entropy data and restart test
  entropy data required for the SP800-90B analysis

# Author
Stephan Mueller <smueller@chronox.de>
