#!/usr/bin/env perl

use strict;
use warnings;
use test;

test::cipher("aes-192-ecb", 24, 0);
