#!/usr/bin/env perl

use strict;
use warnings;
use test;

test::cipher("aes-256-ecb", 32, 0);
