#!/usr/bin/env perl

use strict;
use warnings;
use test;

test::dsasignverify("max");
