#ifndef __INCLUDE_GUARD_CONSTANTS_H
#define __INCLUDE_GUARD_CONSTANTS_H

/* interval between rebalance attempts in seconds */
#define SLEEP_INTERVAL 10

#define NSEC_PER_SEC 1e9

#endif
