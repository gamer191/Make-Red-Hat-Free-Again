# PKCS #11 openCryptoki for Linux HOWTO

Please see manual [openCryptoki - An Open Source Implementation of PKCS #11](https://www.ibm.com/docs/en/linux-on-systems?topic=11-version-317)
for details about openCryptoki, how to install and configure it, and some programming examples.