#
# wrapper script to provide the python-cracklib functionality with the
# module name of the older python-crack package
#
from cracklib import *

