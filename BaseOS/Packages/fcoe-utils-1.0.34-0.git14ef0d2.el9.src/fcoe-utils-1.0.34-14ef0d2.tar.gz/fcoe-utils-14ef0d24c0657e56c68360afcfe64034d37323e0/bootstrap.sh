#! /bin/sh
exec autoreconf --install -s
