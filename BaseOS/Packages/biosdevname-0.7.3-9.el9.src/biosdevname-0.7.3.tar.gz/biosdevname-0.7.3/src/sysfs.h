extern int sysfs_path_is_file(const char *path);
extern int sysfs_read_file(const char *path, char **output);
