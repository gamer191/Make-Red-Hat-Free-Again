# The values in this file are populated by setup.py build
pkg_version = "PKG_VERSION"
