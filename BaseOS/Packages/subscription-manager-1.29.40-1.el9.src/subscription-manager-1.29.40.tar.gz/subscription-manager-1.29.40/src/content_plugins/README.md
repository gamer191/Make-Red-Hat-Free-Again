RHSM plugins
------------

This directory contains plugins for subscription-manager itself so it is aware
of content and repositories of external systems.
