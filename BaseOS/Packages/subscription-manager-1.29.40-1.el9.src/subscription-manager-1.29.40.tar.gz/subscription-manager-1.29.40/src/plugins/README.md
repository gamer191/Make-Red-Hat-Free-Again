Package manager plugins
-----------------------

This directory contains all the plugins for package managers to integrate with
subscription-manager: this way they can for example map a certain repository
with the certificate needed for it.
