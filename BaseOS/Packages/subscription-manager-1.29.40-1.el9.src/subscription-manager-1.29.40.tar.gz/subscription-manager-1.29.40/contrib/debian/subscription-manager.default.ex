# Defaults for subscription-manager initscript
# sourced by /etc/init.d/subscription-manager
# installed at /etc/default/subscription-manager by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
