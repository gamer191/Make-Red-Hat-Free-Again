#! /usr/bin/python
from subscription_manager.base_plugin import SubManPlugin


class NoApiVersionPlugin(SubManPlugin):
    pass
