#! /usr/bin/python

from subscription_manager.base_plugin import SubManPlugin

requires_api_version = "0.0"


class OldApiVersionPlugin(SubManPlugin):
    pass
