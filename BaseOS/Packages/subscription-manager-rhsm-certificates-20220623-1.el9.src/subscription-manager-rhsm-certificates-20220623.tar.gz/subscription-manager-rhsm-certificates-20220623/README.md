subscription-manager-rhsm-certificates
======================================

The Subscription Manager RHSM certificates provides the certificates used
to connect to the Red Hat Subscription Management.

The content here is mostly useful for
[subscription-manager](https://github.com/candlepin/subscription-manager);
please check it out to know more about it.
