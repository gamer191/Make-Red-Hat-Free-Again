extern char version[];
#define MCELOG_VERSION version

