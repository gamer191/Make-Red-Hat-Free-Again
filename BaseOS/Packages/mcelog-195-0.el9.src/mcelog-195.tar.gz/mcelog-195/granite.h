void granite_decode_model(int cputype, int bank, u64 status, u64 misc);
void granite_memerr_misc(struct mce *m, int *channel, int *dimm);
