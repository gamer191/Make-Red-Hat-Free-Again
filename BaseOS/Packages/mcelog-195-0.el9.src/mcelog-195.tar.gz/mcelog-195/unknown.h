void unknown_setup(void);
void run_unknown_trigger(int socket, int cpu, struct mce *log);
