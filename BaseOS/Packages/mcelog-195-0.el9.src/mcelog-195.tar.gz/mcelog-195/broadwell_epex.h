void bdw_epex_decode_model(int cputype, int bank, u64 status, u64 misc);
int bdw_epex_ce_type(int bank, u64 status, u64 misc);
