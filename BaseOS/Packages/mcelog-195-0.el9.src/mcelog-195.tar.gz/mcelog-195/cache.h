int cache_to_cpus(int cpu, unsigned level, unsigned type, 
		  int *cpulen, unsigned **cpumap);
