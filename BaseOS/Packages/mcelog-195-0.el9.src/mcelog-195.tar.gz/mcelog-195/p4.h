char *intel_bank_name(int num);
void decode_intel_mc(struct mce *log, int cpu, int *ismemerr, unsigned len);


