void tulsa_decode_model(u64 status, u64 misc);
