#define PREFIX ""

#define LOG_DEV_FILENAME "/dev/mcelog"
#define DIMM_DB_FILENAME PREFIX "/var/lib/memory-errors"
#define CONFIG_FILENAME PREFIX "/etc/mcelog/mcelog.conf"

#define SOCKET_PATH "/var/run/mcelog-client"

#define LOG_FILE "/var/log/mcelog"

#define PID_FILE "/var/run/mcelog.pid"
