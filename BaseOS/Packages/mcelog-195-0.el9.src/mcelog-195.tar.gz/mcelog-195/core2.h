void core2_decode_model(u64 status);
void p6old_decode_model(u64 status);
