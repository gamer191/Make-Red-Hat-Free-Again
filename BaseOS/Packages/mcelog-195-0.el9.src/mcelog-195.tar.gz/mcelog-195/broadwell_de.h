void bdw_d_decode_model(int cputype, int bank, u64 status, u64 misc);
void bdw_de_decode_model(int cputype, int bank, u64 status, u64 misc);
