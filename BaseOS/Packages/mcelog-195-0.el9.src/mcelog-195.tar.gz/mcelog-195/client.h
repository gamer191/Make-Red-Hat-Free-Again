void ask_server(char *command);
void client_cleanup(void);
